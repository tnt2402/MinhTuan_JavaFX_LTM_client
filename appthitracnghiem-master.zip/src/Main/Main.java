package Main;

import View.Login;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(Login::new);
    }
}